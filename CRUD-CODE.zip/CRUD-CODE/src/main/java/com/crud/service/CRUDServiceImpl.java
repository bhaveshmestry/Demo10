package com.crud.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.ICRUDDao;
import com.crud.model.CRUDModel;

@Service
public class CRUDServiceImpl implements ICRUDService{

	@Autowired
	ICRUDDao dao;
	
	public void add(CRUDModel model) {
		
		System.out.println("In add(model) method - Class : CRUDServiceImpl");
		dao.add(model);
		
	}

	public ArrayList<CRUDModel> list(CRUDModel model) {
		System.out.println("In list(model) method - Class : CRUDServiceImpl");
		return dao.list(model);
	}

	public void delete(CRUDModel model) {
		System.out.println("In delete(model) method - Class : CRUDServiceImpl");
		dao.delete(model);
		
	}

	public void update(CRUDModel model) {
		System.out.println("In update(model) method - Class : CRUDServiceImpl");
		dao.update(model);
		
	}

	public boolean login(CRUDModel model) {
		// TODO Auto-generated method stub
		return dao.login(model);
	}

}
