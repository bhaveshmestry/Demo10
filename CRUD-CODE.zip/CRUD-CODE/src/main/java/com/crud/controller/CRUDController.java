package com.crud.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.crud.model.CRUDModel;
import com.crud.service.ICRUDService;

@Controller
public class CRUDController {

	@Autowired
	ICRUDService service;
	
	@RequestMapping(value="/")
	public String index(Model m)
	{
		System.out.println("In index() method - Class : CRUDController");
		m.addAttribute("loginObj",new CRUDModel());
		return "index";
	}
	
	@RequestMapping(value="/login")
	public String login(Model m , @ModelAttribute("loginObj") CRUDModel model , HttpSession session)
	{
		System.out.println("In login() method - Class : CRUDController");
		if(!service.login(model))
		{
			return "index";
		}
		m.addAttribute("model",new CRUDModel());
		session.setAttribute("userID", model.getId());
		System.out.println(session.getAttribute("userID"));
		return "operation";
	}
	
	@RequestMapping(value="/operations",params="ADD",method=RequestMethod.POST)
    public String add(Model m,@ModelAttribute("model")CRUDModel model)
    {
		System.out.println("In add() method - Class : CRUDController");
        m.addAttribute("addObj", new CRUDModel());
        return "add";
    }
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
    public String addSuccess(Model m,@ModelAttribute("addObj")CRUDModel model)
    {
		System.out.println("In addSuccess() method - Class : CRUDController");
		service.add(model);
        m.addAttribute("model", new CRUDModel());
        return "operation";
    }
	
	@RequestMapping(value="/operations",params="DELETE",method=RequestMethod.POST)
    public String delete(Model m,@ModelAttribute("model")CRUDModel model)
    {
		System.out.println("In delete() method - Class : CRUDController");
        m.addAttribute("deleteObj", new CRUDModel());
        return "delete";
    }
	
	@RequestMapping(value="/delete",method=RequestMethod.POST)
    public String deleteSuccess(Model m,@ModelAttribute("deleteObj")CRUDModel model)
    {
		System.out.println("In deleteSuccess() method - Class : CRUDController");
		service.delete(model);
        m.addAttribute("model", new CRUDModel());
        return "operation";
    }
	
	@RequestMapping(value="/operations",params="UPDATE",method=RequestMethod.POST)
    public String update(Model m,@ModelAttribute("model")CRUDModel model)
    {
		System.out.println("In deleteSuccess() method - Class : CRUDController");
		m.addAttribute("updateObj", new CRUDModel());
        return "update";
    }
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
    public String updateSuccess(Model m,@ModelAttribute("updateObj")CRUDModel model)
    {
		System.out.println("In updateSuccess() method - Class : CRUDController");
		service.update(model);
        m.addAttribute("model", new CRUDModel());
        return "operation";
    }
	
	@RequestMapping(value="/operations",params="LIST",method=RequestMethod.POST)
    public String list(Model m,@ModelAttribute("model")CRUDModel model)
    {
		System.out.println("In list() method - Class : CRUDController");
		ArrayList<CRUDModel> list = service.list(model);
		for(CRUDModel model1 : list)
		{
			System.out.println(model1);
		}
		m.addAttribute("list",list);
		m.addAttribute("listObj", new CRUDModel());
        return "list";
    }

	@RequestMapping(value="/list", method=RequestMethod.POST)
    public String backTolist(Model m,@ModelAttribute("listObj")CRUDModel model)
    {
		System.out.println("In backTolist() method - Class : CRUDController");
		m.addAttribute("model", new CRUDModel());
        return "operation";
    }
	
	@RequestMapping(value="/operations",params="LOGOUT",method=RequestMethod.POST)
    public String logout(Model m,@ModelAttribute("model")CRUDModel model ,  HttpSession session)
    {
		System.out.println("In logout() method - Class : CRUDController");
		System.out.println(session.getAttribute("userID"));
		session.invalidate();
		m.addAttribute("loginObj",new CRUDModel());
        return "index";
    }
	
}
