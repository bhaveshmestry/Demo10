package com.crud.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.query.criteria.internal.CriteriaUpdateImpl;
import org.springframework.stereotype.Repository;
import com.crud.model.CRUDModel;

@Transactional
@Repository
public class CRUDDaoImpl implements ICRUDDao{

	@PersistenceContext
	EntityManager mgr;
	
	public void add(CRUDModel model) {
		
		System.out.println("In add(model) method - Class : CRUDDaoImpl");
		mgr.persist(model);
		
	}

	public ArrayList<CRUDModel> list(CRUDModel model) {
		
		System.out.println("In list(model) method - Class : CRUDDaoImpl");
		ArrayList<CRUDModel> list = (ArrayList<CRUDModel>) mgr.createQuery("select crud from CRUDModel crud").getResultList();
		return list;
		
	}

	public void delete(CRUDModel model) {
		System.out.println("In delete(model) method - Class : CRUDDaoImpl");
		CRUDModel row = mgr.find(CRUDModel.class , model.getId());
		mgr.remove(row);
		
	}

	public void update(CRUDModel model) {
		System.out.println("In update(model) method - Class : CRUDDaoImpl");
		mgr.merge(model);
		
	}

	public boolean login(CRUDModel model) {
		Query qry1 = mgr.createQuery("select b from CRUDModel b where b.username=:username");
		ArrayList<CRUDModel> list1 = (ArrayList<CRUDModel>) qry1.setParameter("username", model.getUsername()).getResultList();
		if(list1.isEmpty())
		{
			System.out.println("User doesn't exist");
			return false;
		}
		Query qry2 = mgr.createQuery("select b from CRUDModel b where b.username=:username AND b.password=:password");
		ArrayList<CRUDModel> list2 = (ArrayList<CRUDModel>) qry2.setParameter("username", model.getUsername()).setParameter("password", model.getPassword()).getResultList();
		if(list2.isEmpty())
		{
			System.out.println("Password is wrong");
			return false;
		}
		return true;
	}

}
