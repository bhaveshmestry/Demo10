package com.crud.dao;

import java.util.ArrayList;

import com.crud.model.CRUDModel;

public interface ICRUDDao {

	void add(CRUDModel model);

	ArrayList<CRUDModel> list(CRUDModel model);

	void delete(CRUDModel model);

	void update(CRUDModel model);

	boolean login(CRUDModel model);

}
